#!/usr/bin/env bash
set -euo pipefail

# Run all services locally with default ports
(
  cd services/user-service && uvicorn app:app --reload --port 8000 &
)
(
  cd services/policy-service && uvicorn app:app --reload --port 8001 &
)
(
  cd services/leave-service && uvicorn app:app --reload --port 8002 &
)
(
  cd services/notification-service && uvicorn app:app --reload --port 8003 &
)

echo "All services started. Press Ctrl+C to stop."
wait
