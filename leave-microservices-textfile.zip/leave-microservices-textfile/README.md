# Leave Management Microservices (File-backed, FastAPI)

Python/FastAPI microservices using **JSON/NDJSON files** instead of databases.

## Services & Ports
- User Service — `:8000`
- Policy Service — `:8001`
- Leave Service — `:8002`
- Notification Service — `:8003`

## Quick Start (no Docker)
```bash
# 1) Create venv and install dependencies
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2) Run all services
chmod +x run_dev.sh
./run_dev.sh

# 3) Open docs
http://localhost:8000/docs
http://localhost:8001/docs
http://localhost:8002/docs
http://localhost:8003/docs
```

## Quick Start (Docker)
```bash
docker compose up --build
```

## Environment Variables
Each service supports a `.env` (copy from `.env.example`). For local dev (no Docker), defaults already match the ports above.

## Storage
Each service keeps files in `services/<service>/storage` with **atomic writes** and **process-safe locks**.

## Notes
- This is a **skeleton**: add validations (date ranges, overlapping leaves), JWT/RBAC, retries, etc.
- Notification service queues messages into `outbox.ndjson` (text-based dev mailbox).
```
{"type":"email","to":"manager@example.com","subject":"...","body":"...","ref":"leave#1","at":"..."}
```

## Testing the Flow (curl)
```bash
# Create manager
curl -X POST localhost:8000/users -H 'Content-Type: application/json' -d '{"name":"Manager","email":"mgr@ex.com","role":"MANAGER"}'
# Create employee with manager_id=1
curl -X POST localhost:8000/users -H 'Content-Type: application/json' -d '{"name":"Emp","email":"emp@ex.com","role":"EMPLOYEE","manager_id":1}'
# Apply leave
curl -X POST localhost:8002/leaves/apply -H 'Content-Type: application/json' -d '{"user_id":2,"leave_type":"SICK","start_date":"2026-02-10","end_date":"2026-02-11"}'
# Approve as manager 1
curl -X PUT localhost:8002/leaves/1/approve -H 'Content-Type: application/json' -d '{"approver_id":1}'
```
