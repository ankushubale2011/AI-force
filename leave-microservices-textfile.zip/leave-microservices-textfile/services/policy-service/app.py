import os
from typing import List
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from utils import write_json_atomic, read_json_safe, file_lock
from models import Policy

load_dotenv()

PORT = int(os.getenv('PORT', '8001'))
STORAGE = os.getenv('STORAGE_DIR', 'storage')
POLICIES = os.path.join(STORAGE, 'policies.json')
LOCK_DIR = os.path.join(STORAGE, 'locks', 'policies.lock')

app = FastAPI(title='Policy Service (File-backed)')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.on_event('startup')
async def startup():
    os.makedirs(os.path.dirname(LOCK_DIR), exist_ok=True)
    if not os.path.exists(POLICIES):
        # seed default policies
        defaults = [
            {"leave_type": "SICK", "max_days_per_year": 10, "requires_manager_approval": True},
            {"leave_type": "CASUAL", "max_days_per_year": 12, "requires_manager_approval": True},
            {"leave_type": "EARNED", "max_days_per_year": 18, "requires_manager_approval": True}
        ]
        write_json_atomic(POLICIES, defaults)

@app.get('/health')
def health():
    return {"status": "ok"}

@app.get('/policies')
def get_policies():
    return read_json_safe(POLICIES, [])

@app.get('/policies/{leave_type}')
def get_policy(leave_type: str):
    policies = read_json_safe(POLICIES, [])
    for p in policies:
        if p['leave_type'].upper() == leave_type.upper():
            return p
    raise HTTPException(status_code=404, detail='Policy not found')

@app.post('/policies')
def upsert_policy(policy: Policy):
    with file_lock(LOCK_DIR):
        policies = read_json_safe(POLICIES, [])
        lt = policy.leave_type.upper()
        updated = False
        for i, p in enumerate(policies):
            if p['leave_type'].upper() == lt:
                policies[i] = {
                    'leave_type': lt,
                    'max_days_per_year': policy.max_days_per_year,
                    'requires_manager_approval': policy.requires_manager_approval
                }
                updated = True
                break
        if not updated:
            policies.append({
                'leave_type': lt,
                'max_days_per_year': policy.max_days_per_year,
                'requires_manager_approval': policy.requires_manager_approval
            })
        write_json_atomic(POLICIES, policies)
        return {'message': 'upserted'}
