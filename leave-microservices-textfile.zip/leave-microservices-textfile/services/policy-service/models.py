from pydantic import BaseModel

class Policy(BaseModel):
    leave_type: str
    max_days_per_year: int
    requires_manager_approval: bool = True
