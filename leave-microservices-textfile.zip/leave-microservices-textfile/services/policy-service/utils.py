import os, json, time, uuid
from contextlib import contextmanager
from typing import Any

# --- Simple directory-based lock (works across processes) ---
@contextmanager
def file_lock(lock_dir: str, timeout: float = 5.0, poll: float = 0.05):
    os.makedirs(os.path.dirname(lock_dir), exist_ok=True)
    start = time.time()
    while True:
        try:
            os.mkdir(lock_dir)
            break
        except FileExistsError:
            if (time.time() - start) > timeout:
                raise TimeoutError(f"Timeout acquiring lock: {lock_dir}")
            time.sleep(poll)
    try:
        yield
    finally:
        try:
            os.rmdir(lock_dir)
        except FileNotFoundError:
            pass


def write_json_atomic(path: str, data: Any) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp.{uuid.uuid4().hex}"
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def read_json_safe(path: str, default: Any):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return default


def append_ndjson_line(path: str, obj: Any) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    line = json.dumps(obj, ensure_ascii=False)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(line + '
')
        f.flush(); os.fsync(f.fileno())

