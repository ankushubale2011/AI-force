from pydantic import BaseModel, EmailStr
from typing import Optional

class UserIn(BaseModel):
    name: str
    email: EmailStr
    role: str = "EMPLOYEE"  # EMPLOYEE | MANAGER | HR
    manager_id: Optional[int] = None
    department: Optional[str] = None

class UserOut(UserIn):
    id: int
    created_at: str
