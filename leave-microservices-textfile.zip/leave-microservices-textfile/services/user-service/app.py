import os, json
from datetime import datetime, timezone
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from utils import file_lock, write_json_atomic, read_json_safe
from models import UserIn

load_dotenv()

PORT = int(os.getenv('PORT', '8000'))
STORAGE = os.getenv('STORAGE_DIR', 'storage')
USERS = os.path.join(STORAGE, 'users.json')
COUNTERS = os.path.join(STORAGE, 'counters.json')
EMAIL_INDEX = os.path.join(STORAGE, 'index_email.json')
LOCK_DIR = os.path.join(STORAGE, 'locks', 'users.lock')

app = FastAPI(title='User Service (File-backed)')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

# --- Startup: ensure storage files exist ---
@app.on_event('startup')
async def startup():
    os.makedirs(os.path.dirname(LOCK_DIR), exist_ok=True)
    if not os.path.exists(USERS):
        write_json_atomic(USERS, [])
    if not os.path.exists(COUNTERS):
        write_json_atomic(COUNTERS, {"user_id": 0})
    if not os.path.exists(EMAIL_INDEX):
        write_json_atomic(EMAIL_INDEX, {})

@app.get('/health')
def health():
    return {"status": "ok"}

@app.post('/users')
def create_user(body: UserIn):
    with file_lock(LOCK_DIR):
        users = read_json_safe(USERS, [])
        counters = read_json_safe(COUNTERS, {"user_id": 0})
        email_idx = read_json_safe(EMAIL_INDEX, {})

        if body.email in email_idx:
            raise HTTPException(status_code=409, detail='Email already exists')

        counters['user_id'] += 1
        new_user = {
            'id': counters['user_id'],
            'name': body.name,
            'email': body.email,
            'role': body.role,
            'manager_id': body.manager_id,
            'department': body.department,
            'created_at': datetime.now(timezone.utc).isoformat()
        }
        users.append(new_user)
        email_idx[body.email] = new_user['id']

        write_json_atomic(USERS, users)
        write_json_atomic(COUNTERS, counters)
        write_json_atomic(EMAIL_INDEX, email_idx)
        return {'id': new_user['id'], 'message': 'User created'}

@app.get('/users/{user_id}')
def get_user(user_id: int):
    users = read_json_safe(USERS, [])
    for u in users:
        if u['id'] == user_id:
            return u
    raise HTTPException(status_code=404, detail='User not found')

@app.get('/users')
def list_users(manager_id: Optional[int] = Query(default=None)):
    users = read_json_safe(USERS, [])
    if manager_id is not None:
        return [u for u in users if (u.get('manager_id') == manager_id)]
    return users

@app.put('/users/{user_id}')
def update_user(user_id: int, body: UserIn):
    with file_lock(LOCK_DIR):
        users = read_json_safe(USERS, [])
        email_idx = read_json_safe(EMAIL_INDEX, {})
        idx = next((i for i, u in enumerate(users) if u['id'] == user_id), -1)
        if idx == -1:
            raise HTTPException(status_code=404, detail='User not found')

        # email uniqueness
        existing = users[idx]
        if body.email != existing['email']:
            if body.email in email_idx:
                raise HTTPException(status_code=409, detail='Email already exists')
            # update email index
            email_idx.pop(existing['email'], None)
            email_idx[body.email] = user_id

        users[idx] = {
            'id': user_id,
            'name': body.name,
            'email': body.email,
            'role': body.role,
            'manager_id': body.manager_id,
            'department': body.department,
            'created_at': existing.get('created_at')
        }
        write_json_atomic(USERS, users)
        write_json_atomic(EMAIL_INDEX, email_idx)
        return {'message': 'updated'}
