import os, json
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import requests

from utils import file_lock, write_json_atomic, read_json_safe, append_ndjson_line
from models import LeaveIn, DecisionIn

load_dotenv()

PORT = int(os.getenv('PORT', '8002'))
STORAGE = os.getenv('STORAGE_DIR', 'storage')
LEAVES = os.path.join(STORAGE, 'leaves.json')
COUNTERS = os.path.join(STORAGE, 'counters.json')
LOGS = os.path.join(STORAGE, 'logs.ndjson')
LOCK_DIR = os.path.join(STORAGE, 'locks', 'leaves.lock')

USER_SVC = os.getenv('USER_SERVICE_URL', 'http://localhost:8000')
POLICY_SVC = os.getenv('POLICY_SERVICE_URL', 'http://localhost:8001')
NOTIF_SVC = os.getenv('NOTIFICATION_SERVICE_URL', 'http://localhost:8003')

app = FastAPI(title='Leave Service (File-backed)')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.on_event('startup')
async def startup():
    os.makedirs(os.path.dirname(LOCK_DIR), exist_ok=True)
    if not os.path.exists(LEAVES):
        write_json_atomic(LEAVES, [])
    if not os.path.exists(COUNTERS):
        write_json_atomic(COUNTERS, {"leave_id": 0})
    if not os.path.exists(LOGS):
        open(LOGS, 'a', encoding='utf-8').close()

@app.get('/health')
def health():
    return {"status": "ok"}

@app.post('/leaves/apply')
def apply_leave(body: LeaveIn):
    # 1) validate user
    u = requests.get(f"{USER_SVC}/users/{body.user_id}")
    if u.status_code == 404:
        raise HTTPException(status_code=400, detail='User not found')
    u.raise_for_status()
    user = u.json()

    # 2) validate policy
    p = requests.get(f"{POLICY_SVC}/policies/{body.leave_type}")
    if p.status_code == 404:
        raise HTTPException(status_code=400, detail='Policy not found')
    p.raise_for_status()
    policy = p.json()

    # TODO: Add date validation & overlapping checks (skeleton keeps it simple)

    with file_lock(LOCK_DIR):
        leaves = read_json_safe(LEAVES, [])
        counters = read_json_safe(COUNTERS, {"leave_id": 0})
        counters['leave_id'] += 1
        leave = {
            'id': counters['leave_id'],
            'user_id': body.user_id,
            'leave_type': body.leave_type.upper(),
            'start_date': body.start_date,
            'end_date': body.end_date,
            'status': 'PENDING',
            'applied_at': datetime.now(timezone.utc).isoformat(),
            'comments': body.comments
        }
        leaves.append(leave)
        write_json_atomic(LEAVES, leaves)
        write_json_atomic(COUNTERS, counters)
        append_ndjson_line(LOGS, {'event': 'APPLY', 'leave_id': leave['id'], 'at': leave['applied_at']})

    # 3) notify manager (best-effort)
    try:
        # In a real app, fetch manager email/id via User Service; here we just log
        requests.post(f"{NOTIF_SVC}/notify/email", json={
            'to': user.get('manager_id', 'manager@example.com'),
            'subject': f"Leave request #{leave['id']}",
            'body': f"User {body.user_id} requested {body.leave_type} leave {body.start_date} to {body.end_date}",
            'ref': f"leave#{leave['id']}"
        }, timeout=2)
    except Exception:
        pass

    return {'id': leave['id'], 'status': leave['status']}

@app.get('/leaves/{leave_id}')
def get_leave(leave_id: int):
    leaves = read_json_safe(LEAVES, [])
    for l in leaves:
        if l['id'] == leave_id:
            return l
    raise HTTPException(status_code=404, detail='Leave not found')

@app.get('/leaves/user/{user_id}')
def get_user_leaves(user_id: int):
    leaves = read_json_safe(LEAVES, [])
    return [l for l in leaves if l.get('user_id') == user_id]

@app.put('/leaves/{leave_id}/approve')
def approve_leave(leave_id: int, d: DecisionIn):
    # verify approver is manager of applicant
    leave = None
    leaves = read_json_safe(LEAVES, [])
    for l in leaves:
        if l['id'] == leave_id:
            leave = l
            break
    if not leave:
        raise HTTPException(status_code=404, detail='Leave not found')

    u = requests.get(f"{USER_SVC}/users/{leave['user_id']}")
    if u.status_code == 404:
        raise HTTPException(status_code=400, detail='User not found')
    user = u.json()
    if user.get('manager_id') != d.approver_id:
        raise HTTPException(status_code=403, detail='Only manager can approve')

    with file_lock(LOCK_DIR):
        leaves = read_json_safe(LEAVES, [])
        for i, l in enumerate(leaves):
            if l['id'] == leave_id:
                l['status'] = 'APPROVED'
                l['decision_at'] = datetime.now(timezone.utc).isoformat()
                l['decision_by'] = d.approver_id
                l['comments'] = d.comments
                leaves[i] = l
                break
        write_json_atomic(LEAVES, leaves)
        append_ndjson_line(LOGS, {'event': 'APPROVE', 'leave_id': leave_id, 'by': d.approver_id, 'at': datetime.now(timezone.utc).isoformat()})

    try:
        requests.post(f"{NOTIF_SVC}/notify/email", json={
            'to': user.get('email', 'employee@example.com'),
            'subject': f"Leave approved #{leave_id}",
            'body': f"Your leave #{leave_id} has been approved",
            'ref': f"leave#{leave_id}"
        }, timeout=2)
    except Exception:
        pass

    return {'message': 'approved'}

@app.put('/leaves/{leave_id}/reject')
def reject_leave(leave_id: int, d: DecisionIn):
    leave = None
    leaves = read_json_safe(LEAVES, [])
    for l in leaves:
        if l['id'] == leave_id:
            leave = l
            break
    if not leave:
        raise HTTPException(status_code=404, detail='Leave not found')

    u = requests.get(f"{USER_SVC}/users/{leave['user_id']}")
    if u.status_code == 404:
        raise HTTPException(status_code=400, detail='User not found')
    user = u.json()
    if user.get('manager_id') != d.approver_id:
        raise HTTPException(status_code=403, detail='Only manager can reject')

    with file_lock(LOCK_DIR):
        leaves = read_json_safe(LEAVES, [])
        for i, l in enumerate(leaves):
            if l['id'] == leave_id:
                l['status'] = 'REJECTED'
                l['decision_at'] = datetime.now(timezone.utc).isoformat()
                l['decision_by'] = d.approver_id
                l['comments'] = d.comments
                leaves[i] = l
                break
        write_json_atomic(LEAVES, leaves)
        append_ndjson_line(LOGS, {'event': 'REJECT', 'leave_id': leave_id, 'by': d.approver_id, 'at': datetime.now(timezone.utc).isoformat()})

    try:
        requests.post(f"{NOTIF_SVC}/notify/email", json={
            'to': user.get('email', 'employee@example.com'),
            'subject': f"Leave rejected #{leave_id}",
            'body': f"Your leave #{leave_id} has been rejected",
            'ref': f"leave#{leave_id}"
        }, timeout=2)
    except Exception:
        pass

    return {'message': 'rejected'}
