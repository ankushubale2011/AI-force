from pydantic import BaseModel
from typing import Optional

class LeaveIn(BaseModel):
    user_id: int
    leave_type: str
    start_date: str  # YYYY-MM-DD
    end_date: str
    comments: Optional[str] = None

class DecisionIn(BaseModel):
    approver_id: int
    comments: Optional[str] = None
