import os
from datetime import datetime, timezone
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from utils import append_ndjson_line
from models import EmailNotification, TeamsNotification

load_dotenv()

PORT = int(os.getenv('PORT', '8003'))
STORAGE = os.getenv('STORAGE_DIR', 'storage')
OUTBOX = os.path.join(STORAGE, 'outbox.ndjson')

app = FastAPI(title='Notification Service (File-backed)')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.get('/health')
def health():
    return {"status": "ok"}

@app.post('/notify/email')
def notify_email(n: EmailNotification):
    append_ndjson_line(OUTBOX, {
        'type': 'email',
        'to': n.to,
        'subject': n.subject,
        'body': n.body,
        'ref': n.ref,
        'at': datetime.now(timezone.utc).isoformat()
    })
    return {'queued': True}

@app.post('/notify/teams')
def notify_teams(n: TeamsNotification):
    append_ndjson_line(OUTBOX, {
        'type': 'teams',
        'to': n.to,
        'message': n.message,
        'ref': n.ref,
        'at': datetime.now(timezone.utc).isoformat()
    })
    return {'queued': True}
