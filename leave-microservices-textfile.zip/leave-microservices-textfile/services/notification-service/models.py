from pydantic import BaseModel, EmailStr
from typing import Optional

class EmailNotification(BaseModel):
    to: EmailStr | str  # allow raw string for dev
    subject: str
    body: str
    ref: Optional[str] = None

class TeamsNotification(BaseModel):
    to: str
    message: str
    ref: Optional[str] = None
